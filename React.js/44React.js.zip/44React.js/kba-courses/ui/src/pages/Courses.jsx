import React from 'react'
import CourseGrid from '../components/CourseGrid'

const Courses = () => {
  return (
   
       <CourseGrid isHome={false} />
    
  )
}

export default Courses